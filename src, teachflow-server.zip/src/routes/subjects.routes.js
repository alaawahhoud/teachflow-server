import { Router } from "express";
import multer from "multer";
import {
  listSubjects, createSubject, updateSubject, deleteSubject,
  listSubjectTeachers, addSubjectTeacher, removeSubjectTeacher
} from "../controllers/subjects.controller.js";

const r = Router();
const upload = multer();

// CRUD subjects
r.get("/", listSubjects);
r.post("/", upload.none(), createSubject);
r.patch("/:id", upload.none(), updateSubject);
r.delete("/:id", deleteSubject);

// Linking teacher <-> subject
r.get("/:id/teachers", listSubjectTeachers);
r.post("/:id/teachers/:userId", addSubjectTeacher);      // ربط
r.delete("/:id/teachers/:userId", removeSubjectTeacher);  // فك الربط

export default r;
