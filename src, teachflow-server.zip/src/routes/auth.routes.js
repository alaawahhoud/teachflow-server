import { Router } from "express";
import {
  register,
  login,
  me,
  refresh,
  logout,
  authRequired,
} from "./auth.controller.js"; // ✅ المسار لازم يكون صحيح نسبياً للملف

const router = Router();

router.post("/register", register);
router.post("/login", login);
router.post("/refresh", refresh);
router.get("/me", authRequired, me);
router.post("/logout", logout);

export default router;
