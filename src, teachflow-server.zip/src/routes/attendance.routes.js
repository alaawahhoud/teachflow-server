import { Router } from 'express';
import { list, create, update } from '../controllers/attendance.controller.js';

const router = Router();
router.get('/', list);
router.post('/', create);
router.put('/:id', update);
export default router;
