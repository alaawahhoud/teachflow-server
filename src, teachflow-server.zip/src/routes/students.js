import { Router } from "express";
import { pool } from "../db.js";

const router = Router();

/* GET list with filters (grade/subject by id or 'All'), + search name/status */
router.get("/", async (req, res) => {
  try {
    const { grade = "All", subject = "All", q = "", status = "" } = req.query;

    const where = [];
    const params = [];

    if (grade !== "All")   { where.push("s.class_id = ?"); params.push(Number(grade)); }
    if (subject !== "All") { where.push("s.subject_id = ?"); params.push(Number(subject)); }
    if (q)                 { where.push("LOWER(s.name) LIKE ?"); params.push(`%${q.toLowerCase()}%`); }
    if (status)            { where.push("LOWER(s.status) LIKE ?"); params.push(`%${status.toLowerCase()}%`); }

    const sql = `
      SELECT s.id, s.name, s.status, s.note, s.created_at,
             c.name AS grade, sub.name AS subject
      FROM students s
      JOIN classes  c   ON c.id = s.class_id
      JOIN subjects sub ON sub.id = s.subject_id
      ${where.length ? "WHERE " + where.join(" AND ") : ""}
      ORDER BY s.id ASC
    `;
    const [rows] = await pool.query(sql, params);
    res.json(rows);
  } catch (e) {
    console.error("GET /api/students", e);
    res.status(500).json({ error: "Failed to fetch students" });
  }
});

/* PUT update status & note */
router.put("/:id", async (req, res) => {
  try {
    const id = Number(req.params.id);
    const { status, note } = req.body || {};
    if (!status) return res.status(400).json({ error: "status is required" });

    await pool.query("UPDATE students SET status = ?, note = ? WHERE id = ?", [status, note ?? null, id]);

    const [rows] = await pool.query(
      `SELECT s.id, s.name, s.status, s.note, s.created_at, c.name AS grade, sub.name AS subject
       FROM students s
       JOIN classes c ON c.id = s.class_id
       JOIN subjects sub ON sub.id = s.subject_id
       WHERE s.id = ?`,
      [id]
    );
    if (!rows.length) return res.status(404).json({ error: "Not found" });
    res.json(rows[0]);
  } catch (e) {
    console.error("PUT /api/students/:id", e);
    res.status(500).json({ error: "Failed to update student" });
  }
});

export default router;
