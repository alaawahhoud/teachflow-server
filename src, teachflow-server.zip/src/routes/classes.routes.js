// routes/classes.routes.js
import { Router } from "express";
import multer from "multer";
import {
  listClasses, listClassSubjects, createClassSubject
} from "../controllers/classes.controller.js";

const r = Router();
const upload = multer();

r.get("/", listClasses);
r.get("/:id/subjects", listClassSubjects);
r.post("/:id/subjects", upload.none(), createClassSubject);

export default r;
