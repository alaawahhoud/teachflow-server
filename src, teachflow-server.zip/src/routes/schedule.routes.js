import { Router } from "express";
import multer from "multer";
import { listSchedule, createSchedule, getScheduleById } from "../controllers/schedule.controller.js";

const r = Router();
const upload = multer();

r.get("/", listSchedule);               // GET /api/schedule?teacher=...&from=...&to=...
r.get("/:id", getScheduleById);         // GET /api/schedule/123
r.post("/", upload.none(), createSchedule); // POST form/json

export default r;
