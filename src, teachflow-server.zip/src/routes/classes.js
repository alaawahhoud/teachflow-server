import { Router } from "express";
import { pool } from "../db.js";

const router = Router();

router.get("/", async (req, res) => {
  try {
    const [rows] = await pool.query(
      "SELECT id, name, grade, section FROM classes ORDER BY id ASC"
    );
    res.json(rows);
  } catch (e) {
    console.error("GET /api/classes", e);
    res.status(500).json({ error: "Failed to fetch classes" });
  }
});

export default router;
