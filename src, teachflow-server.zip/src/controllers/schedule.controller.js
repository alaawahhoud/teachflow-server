import { pool } from "../db.js";

// helper: جِب teacher_id من id أو username أو email
async function resolveTeacherId(teacher) {
  if (!teacher) return null;
  // إذا رقم
  if (/^\d+$/.test(String(teacher))) return Number(teacher);
  // جرّب username/email
  const [[u]] = await pool.query(
    `SELECT id FROM users WHERE username = ? OR email = ? LIMIT 1`,
    [teacher, teacher]
  );
  return u?.id || null;
}

// GET /api/schedule?teacher=<id|username|email>&from=YYYY-MM-DD&to=YYYY-MM-DD
export async function listSchedule(req, res, next) {
  try {
    const { teacher, from, to } = req.query;
    const teacherId = await resolveTeacherId(teacher);

    const conds = [];
    const args = [];

    if (teacherId) { conds.push(`s.teacher_id = ?`); args.push(teacherId); }
    if (from)      { conds.push(`s.start_time >= ?`); args.push(`${from} 00:00:00`); }
    if (to)        { conds.push(`s.end_time   <= ?`); args.push(`${to} 23:59:59`); }

    const where = conds.length ? `WHERE ${conds.join(" AND ")}` : "";

    const [rows] = await pool.query(
      `SELECT s.id, s.teacher_id, u.full_name AS teacher_name,
              s.class_id, c.name AS class_name, c.grade, c.section,
              s.subject_id, sub.name AS subject_name,
              s.day_of_week, s.start_time, s.end_time, s.room
         FROM schedules s
         LEFT JOIN users u   ON u.id = s.teacher_id
         LEFT JOIN classes c ON c.id = s.class_id
         LEFT JOIN subjects sub ON sub.id = s.subject_id
        ${where}
        ORDER BY s.day_of_week, s.start_time`,
      args
    );

    res.json(rows);
  } catch (e) { next(e); }
}

// GET /api/schedule/:id
export async function getScheduleById(req, res, next) {
  try {
    const [[row]] = await pool.query(
      `SELECT s.*, u.full_name AS teacher_name, c.name AS class_name, sub.name AS subject_name
         FROM schedules s
         LEFT JOIN users u ON u.id = s.teacher_id
         LEFT JOIN classes c ON c.id = s.class_id
         LEFT JOIN subjects sub ON sub.id = s.subject_id
        WHERE s.id = ?`,
      [req.params.id]
    );
    if (!row) return res.status(404).json({ message: "Schedule item not found" });
    res.json(row);
  } catch (e) { next(e); }
}

// POST /api/schedule  (يدعم JSON أو FormData)
export async function createSchedule(req, res, next) {
  try {
    const b = req.body || {};
    const teacherId = await resolveTeacherId(b.teacher);
    const classId   = b.class_id ? Number(b.class_id) : null;
    const subjectId = b.subject_id ? Number(b.subject_id) : null;
    const dayOfWeek = Number(b.day_of_week); // 1..7 (Mon..Sun)
    const startTime = b.start_time;          // "08:00"
    const endTime   = b.end_time;            // "08:50"
    const room      = b.room || null;

    if (!teacherId || !classId || !subjectId || !dayOfWeek || !startTime || !endTime) {
      return res.status(400).json({ message: "teacher, class_id, subject_id, day_of_week, start_time, end_time are required" });
    }

    // خزن بجدول schedules (تاريخ الوقت من دون تاريخ—استعمل TIME، واليوم رقم)
    const [r] = await pool.query(
      `INSERT INTO schedules (teacher_id, class_id, subject_id, day_of_week, start_time, end_time, room)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [teacherId, classId, subjectId, dayOfWeek, startTime, endTime, room]
    );

    const [[row]] = await pool.query(
      `SELECT s.id, s.teacher_id, s.class_id, s.subject_id, s.day_of_week, s.start_time, s.end_time, s.room
         FROM schedules s WHERE s.id = ?`, [r.insertId]
    );

    res.status(201).json(row);
  } catch (e) { next(e); }
}
