import express from "express";
import cors from "cors";
import classesRouter from "./routes/classes.js";
import studentsRouter from "./routes/students.js";
import overviewRouter from "./routes/overview.js";
import filtersRouter from "./routes/filters.js";

const app = express();

app.use(cors());
app.use(express.json());

app.get("/", (_req, res) => res.json({ ok: true, service: "TeachFlow API" }));
app.use("/api/classes", classesRouter);
app.use("/api/filters", filtersRouter);
app.use("/api/students", studentsRouter);
app.use("/api/overview", overviewRouter);

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`API running on http://localhost:${PORT}`));
